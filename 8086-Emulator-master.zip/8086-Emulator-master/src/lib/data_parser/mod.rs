#[allow(clippy::all)]
#[rustfmt::skip]
pub mod data_parser;
mod data_parser_tests;
