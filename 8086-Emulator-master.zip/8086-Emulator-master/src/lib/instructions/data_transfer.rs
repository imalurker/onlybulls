/*
MOV
PUSH
POP
XCHG
XLAT
IN : Not Supported
OUT : Not Supported
LEA
LDS : Not Supported
LES : Not Supported
LAHF
SAHF
PUSHF
POPF
*/
