#[allow(clippy::all)]
#[rustfmt::skip]
pub mod interpreter;
mod tests;
